"""Deterministic vector schematics with inspectable chemical connectivity.

No generated raster imagery and no experimental measurements are used.
"""
from pathlib import Path
import json, math, re, html, zipfile
from xml.etree import ElementTree as ET
from rdkit import Chem, rdBase
from rdkit.Chem import rdDepictor, rdMolDescriptors
from rdkit.Chem.Draw import rdMolDraw2D
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import PP_ALIGN
from pptx.oxml.xmlchemy import OxmlElement
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

OUT=Path('/workspace/paper-redraw');OUT.mkdir(exist_ok=True)
STRUCT=OUT/'structures';STRUCT.mkdir(exist_ok=True)
W,H=1000,720
INK='#223043';BLUE='#2369A2';LIGHT='#80B7D7';TEAL='#087F78';ORANGE='#D58228';HBOND='#BE5960';GRAY='#637284';BORDER='#CAD6DF'
pdfmetrics.registerFont(TTFont('PaperSans','/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf'))
pdfmetrics.registerFont(TTFont('PaperSansBold','/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf'))

class Scene:
    def __init__(self,name,title):
        self.name=name;self.title=title;self.items=[]
        self.text(40,53,title,36,INK,True)
        self.text(40,96,'Qualitative schematic • not to scale',28,GRAY)
    def add(self,kind,**kw):self.items.append(dict(kind=kind,**kw));return self.items[-1]
    def rect(self,x,y,w,h,fill='none',stroke=INK,sw=2.4,r=0,group=None):return self.add('rect',x=x,y=y,w=w,h=h,fill=fill,stroke=stroke,sw=sw,r=r,group=group)
    def ellipse(self,x,y,w,h,fill='none',stroke=INK,sw=2.4,dash=None,group=None):return self.add('ellipse',x=x,y=y,w=w,h=h,fill=fill,stroke=stroke,sw=sw,dash=dash,group=group)
    def path(self,pts,stroke=INK,sw=2.4,dash=None,fill='none',closed=False,group=None):return self.add('path',pts=pts,stroke=stroke,sw=sw,dash=dash,fill=fill,closed=closed,group=group)
    def line(self,x1,y1,x2,y2,stroke=INK,sw=2.4,dash=None,group=None):return self.path([(x1,y1),(x2,y2)],stroke,sw,dash,group=group)
    def text(self,x,y,value,size=28,color=INK,bold=False,anchor='start',group=None):return self.add('text',x=x,y=y,value=value,size=size,color=color,bold=bold,anchor=anchor,group=group)
    def curve(self,points,stroke=BLUE,sw=4,dash=None,group=None):
        ext=[points[0]]+points+[points[-1]];out=[]
        for i in range(1,len(ext)-2):
            a,b,c,d=ext[i-1:i+3]
            for j in range(15):
                t=j/15;t2=t*t;t3=t2*t
                out.append(tuple(.5*((2*b[k])+(-a[k]+c[k])*t+(2*a[k]-5*b[k]+4*c[k]-d[k])*t2+(-a[k]+3*b[k]-3*c[k]+d[k])*t3) for k in range(2)))
        out.append(points[-1]);return self.path(out,stroke,sw,dash,group=group)
    def arrow(self,x1,y1,x2,y2,color=BLUE,sw=3,both=False):
        self.line(x1,y1,x2,y2,color,sw)
        for x,y,xx,yy in [(x2,y2,x1,y1)]+([(x1,y1,x2,y2)] if both else []):
            a=math.atan2(y-yy,x-xx);u,v=math.cos(a),math.sin(a)
            self.path([(x,y),(x-15*u+7*v,y-15*v-7*u),(x-15*u-7*v,y-15*v+7*u)],color,1,fill=color,closed=True)
    def ion(self,x,y,positive=False,small=False):
        r=23 if small else 30;col=ORANGE if positive else TEAL
        self.ellipse(x-r,y-r,2*r,2*r,'#FFF8EE' if positive else '#EFF9F7',col,2.8)
        self.text(x,y+10,'+' if positive else '−',30,col,True,'middle')
    def svg(self,path,width_mm=89):
        attrs=lambda d:' '.join(f'{k}="{html.escape(str(v),quote=True)}"' for k,v in d.items() if v is not None)
        rows=[f'<svg xmlns="http://www.w3.org/2000/svg" width="{width_mm}mm" height="{width_mm*H/W}mm" viewBox="0 0 {W} {H}">',f'<title>{html.escape(self.title)}</title>','<rect width="1000" height="720" fill="white"/>']
        for q in self.items:
            k=q['kind']
            if k=='text':
                a=dict(x=q['x'],y=q['y'],fill=q['color'],**{'font-family':'Arial, Liberation Sans, sans-serif','font-size':q['size'],'font-weight':700 if q['bold'] else 400,'text-anchor':q['anchor']})
                rows.append(f'<text {attrs(a)}>{html.escape(q["value"])}</text>');continue
            a=dict(fill=q['fill'],stroke=q['stroke'],**{'stroke-width':q['sw'],'stroke-linecap':'round','stroke-linejoin':'round'})
            if q.get('dash'):a['stroke-dasharray']=' '.join(map(str,q['dash']))
            if k=='rect':a.update(x=q['x'],y=q['y'],width=q['w'],height=q['h'],rx=q['r']);tag='rect'
            elif k=='ellipse':a.update(cx=q['x']+q['w']/2,cy=q['y']+q['h']/2,rx=q['w']/2,ry=q['h']/2);tag='ellipse'
            else:
                a['d']=' '.join(('M' if j==0 else 'L')+f' {p[0]:.3f},{p[1]:.3f}' for j,p in enumerate(q['pts']))+(' Z' if q['closed'] else '');tag='path'
            rows.append(f'<{tag} {attrs(a)}/>')
        rows.append('</svg>');Path(path).write_text('\n'.join(rows),encoding='utf-8')
    def pdf(self,path,width_mm=89):
        scale=width_mm*72/25.4/W;c=canvas.Canvas(str(path),pagesize=(W*scale,H*scale),initialFontName='PaperSans');c.setTitle(self.title);c.translate(0,H*scale);c.scale(scale,-scale)
        for q in self.items:
            k=q['kind']
            if k=='text':
                font='PaperSansBold' if q['bold'] else 'PaperSans';tw=pdfmetrics.stringWidth(q['value'],font,q['size']);x=q['x']-(tw/2 if q['anchor']=='middle' else tw if q['anchor']=='end' else 0)
                c.saveState();c.translate(x,q['y']);c.scale(1,-1);c.setFillColor(q['color']);c.setFont(font,q['size']);c.drawString(0,0,q['value']);c.restoreState();continue
            c.setLineWidth(q['sw']);c.setLineCap(1);c.setLineJoin(1);c.setDash(q.get('dash') or [])
            if q['stroke']!='none':c.setStrokeColor(q['stroke'])
            if q['fill']!='none':c.setFillColor(q['fill'])
            st=int(q['stroke']!='none');fl=int(q['fill']!='none')
            if k=='rect':c.roundRect(q['x'],q['y'],q['w'],q['h'],q['r'],stroke=st,fill=fl)
            elif k=='ellipse':c.ellipse(q['x'],q['y'],q['x']+q['w'],q['y']+q['h'],stroke=st,fill=fl)
            else:
                p=c.beginPath();p.moveTo(*q['pts'][0])
                for pt in q['pts'][1:]:p.lineTo(*pt)
                if q['closed']:p.close()
                c.drawPath(p,stroke=st,fill=fl)
        c.showPage();c.save()

def to_ppt(scene,prs):
    sl=prs.slides.add_slide(prs.slide_layouts[6]);groups={}
    def col(v):return RGBColor.from_string(v.lstrip('#'))
    for q in scene.items:
        k=q['kind']
        if k=='text':
            font='PaperSansBold' if q['bold'] else 'PaperSans';tw=pdfmetrics.stringWidth(q['value'],font,q['size']);x=q['x']-(tw/2 if q['anchor']=='middle' else tw if q['anchor']=='end' else 0)
            sh=sl.shapes.add_textbox(Inches(x/100),Inches((q['y']-q['size']*1.0)/100),Inches((tw+q['size']*.9)/100),Inches(q['size']*1.65/100))
            tf=sh.text_frame;tf.word_wrap=False;tf.margin_left=tf.margin_right=tf.margin_top=tf.margin_bottom=0;p=tf.paragraphs[0];p.text=q['value'];p.font.name='Arial';p.font.size=Pt(q['size']*.72);p.font.bold=q['bold'];p.font.color.rgb=col(q['color']);p.space_after=0
        elif k in ['rect','ellipse']:
            typ=MSO_SHAPE.OVAL if k=='ellipse' else MSO_SHAPE.ROUNDED_RECTANGLE if q['r'] else MSO_SHAPE.RECTANGLE
            sh=sl.shapes.add_shape(typ,Inches(q['x']/100),Inches(q['y']/100),Inches(q['w']/100),Inches(q['h']/100))
            if k=='rect' and q['r']:sh.adjustments[0]=min(.48,q['r']/max(1,min(q['w'],q['h'])))
        else:
            b=sl.shapes.build_freeform(*q['pts'][0],scale=Inches(.01));b.add_line_segments(q['pts'][1:],close=q['closed']);sh=b.convert_to_shape()
        sh.name=q.get('value',q.get('group') or k)[:100]
        if k!='text':
            if q['fill']=='none':sh.fill.background()
            else:sh.fill.solid();sh.fill.fore_color.rgb=col(q['fill'])
            if q['stroke']=='none':sh.line.fill.background()
            else:
                sh.line.color.rgb=col(q['stroke']);sh.line.width=Pt(q['sw']*.72)
                ln=sh._element.spPr.get_or_add_ln();ln.set('cap','rnd');ln.append(OxmlElement('a:round'))
                if q.get('dash'):sh.line.dash_style=4
            sh._element.spPr.append(OxmlElement('a:effectLst'))
            for ref in sh._element.findall('.//{http://schemas.openxmlformats.org/drawingml/2006/main}effectRef'):ref.set('idx','0')
        if q.get('group'):groups.setdefault(q['group'],[]).append(sh)
    for name,members in groups.items():
        g=sl.shapes.add_group_shape(members);g.name=name+' — editable vector group'
    sl.notes_slide.notes_text_frame.text='定性示意图，供作者科学核对。全部为可编辑矢量对象。无实验数值，无生成式图像位图。化学片段省略立体化学，不是优化后的分子构型或真实模拟快照。'
    return sl

def chemical(scene,mol,x,y,w,h,group):
    rdDepictor.Compute2DCoords(mol)
    d=rdMolDraw2D.MolDraw2DSVG(w,h,-1,-1,True);o=d.drawOptions();o.useBWAtomPalette();o.clearBackground=False;o.fixedFontSize=28;o.bondLineWidth=2.6;o.padding=.07
    d.DrawMolecule(mol);d.FinishDrawing();svg=d.GetDrawingText();(STRUCT/(group+'.svg')).write_text(svg)
    coords={a.GetIdx():(x+d.GetDrawCoords(a.GetIdx()).x,y+d.GetDrawCoords(a.GetIdx()).y) for a in mol.GetAtoms()}
    Hlabels={}
    for el in ET.fromstring(svg):
        typ=el.tag.split('}')[-1]
        if typ=='path':
            data=el.get('d','');assert set(re.findall('[A-Za-z]',data))<=set('MLZmlz'),data
            nums=[float(z) for z in re.findall(r'[-+]?\d*\.?\d+(?:[eE][-+]?\d+)?',data)]
            assert len(nums)%2==0
            pts=[(x+nums[i],y+nums[i+1]) for i in range(0,len(nums),2)]
            if len(pts)>1:scene.path(pts,INK,2.6,group=group)
        elif typ=='text':
            style=el.get('style','');fs=float(re.search(r'font-size:([\d.]+)px',style).group(1));val=''.join(el.itertext());xx=x+float(el.get('x'));yy=y+float(el.get('y'))
            scene.text(xx,yy,val,fs,INK,group=group)
            if val=='H':
                mt=re.search(r'atom-(\d+)',el.get('class',''))
                if mt:Hlabels[int(mt.group(1))]=(xx+fs*.35,yy-fs*.35)
    return coords,Hlabels

# Sanitized molecular definitions, with transparent scope and formula checks.
definitions={
 'chloride':('[Cl-]','Cl-',-1),
 'acetate':('CC(=O)[O-]','C2H3O2-',-1),
 'Bmim':('CCCCn1cc[n+](C)c1','C8H15N2+',1),
 'Amim':('C=CCn1cc[n+](C)c1','C7H11N2+',1),
 'Emim':('CCn1cc[n+](C)c1','C6H11N2+',1)}
manifest={'software':'RDKit '+rdBase.rdkitVersion,'external_identity_crosscheck':'PubChem endpoint unavailable (proxy HTTP 403); identity definitions require author confirmation.','molecules':{},'starch_scope':'Three glucose-connectivity units linked through C1–O–C4; stereochemistry intentionally unspecified. This is not an atomistic starch conformation.'}
molecules={}
for name,(smiles,formula,charge) in definitions.items():
    mol=Chem.MolFromSmiles(smiles);assert mol is not None;Chem.SanitizeMol(mol)
    assert rdMolDescriptors.CalcMolFormula(mol)==formula and Chem.GetFormalCharge(mol)==charge
    molecules[name]=mol;rdDepictor.Compute2DCoords(mol);Chem.MolToMolFile(mol,str(STRUCT/(name+'.mol')))
    manifest['molecules'][name]={'smiles':Chem.MolToSmiles(mol),'formula':formula,'formal_charge':charge,'valence_sanitization':'passed'}
base=Chem.MolFromSmiles('OCC1OC(O)C(O)C(O)C1O');rw=Chem.RWMol(Chem.CombineMols(Chem.CombineMols(base,base),base))
rw.AddBond(4,23,Chem.BondType.SINGLE);rw.AddBond(16,35,Chem.BondType.SINGLE)
for atom in [17,5]:rw.RemoveAtom(atom)
glucan=rw.GetMol();Chem.SanitizeMol(glucan);assert rdMolDescriptors.CalcMolFormula(glucan)=='C18H32O16';assert rdMolDescriptors.CalcNumRings(glucan)==3
Chem.MolToMolFile(glucan,str(STRUCT/'glucan_connectivity.mol'))
manifest['molecules']['glucan_connectivity']={'smiles':Chem.MolToSmiles(glucan),'formula':'C18H32O16','stereochemistry':'unspecified','glycosidic_connectivity':'C1–O–C4','valence_sanitization':'passed'}
(STRUCT/'chemical_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))

# 1. Apparatus: controlled, flat-vector cutaway; no unverified settings.
a=Scene('01_MEF装置_矢量示意','MEF heating apparatus')
a.rect(265,184,470,335,'#FAFCFD',INK,2.8,r=22)
a.rect(280,305,440,199,'#E8F3F7','none',0,r=12)
a.ellipse(280,286,440,43,'#F2F8FB','#A7C7D8',2)
a.ellipse(265,494,470,48,'#F6FAFD',INK,2.8)
a.rect(253,166,494,34,'#E2E8EE',INK,2.8,r=11)
for x in [370,630]:
    a.rect(x-13,170,26,256,'#BFC9D1',INK,2.8,r=5)
    a.ellipse(x-23,147,46,30,'#6F7F8B',INK,2.4)
a.text(500,475,'Starch / ionic-liquid medium',30,INK,anchor='middle')
a.text(142,225,'Electrodes',28,INK)
a.line(285,218,355,245,GRAY,2)
a.arrow(432,365,568,365,BLUE,3,True)
a.text(500,348,'E(t)',30,BLUE,True,'middle')
a.rect(375,580,250,105,'#F7FAFC',INK,2.8,r=10)
a.text(500,613,'AC source',30,INK,True,'middle')
a.curve([(405+i*6,649-12*math.sin(i*.5)) for i in range(32)],BLUE,3)
a.curve([(370,150),(215,133),(174,171),(176,565),(409,599)],ORANGE,3.5)
a.curve([(630,150),(778,133),(825,174),(823,562),(590,599)],BLUE,3.5)
a.text(500,565,'Alternating electric field',28,GRAY,anchor='middle')

# 2. Chemically inspectable connectivity and proposed hydroxyl–anion contacts.
b=Scene('02_淀粉离子氢键_矢量示意','Starch–anion contacts')
co,hyd=chemical(b,glucan,70,220,860,350,'glucan_connectivity')
b.ellipse(93,128,94,74,'#EFF9F7',TEAL,2.6)
b.text(140,177,'Cl−',34,TEAL,True,'middle')
b.text(140,235,'Chloride',28,GRAY,anchor='middle')
ac,ah=chemical(b,molecules['acetate'],738,113,215,145,'acetate')
b.text(841,110,'Acetate',28,GRAY,anchor='middle')
acceptor=next(at.GetIdx() for at in molecules['acetate'].GetAtoms() if at.GetFormalCharge()==-1)
for donor,target in [(0,(177,164)),(22,ac[acceptor])]:
    start=hyd.get(donor,co[donor]);dx=target[0]-start[0];dy=target[1]-start[1];ll=math.hypot(dx,dy)
    trim=17
    b.line(start[0]+dx/ll*trim,start[1]+dy/ll*trim,target[0]-dx/ll*trim,target[1]-dy/ll*trim,HBOND,2.8,[9,7])
b.ion(123,580,True);b.ion(875,575,True)
b.text(500,612,'Glucan connectivity; stereochemistry omitted',28,GRAY,anchor='middle')
b.line(70,661,128,661,HBOND,2.8,[9,7]);b.text(145,671,'Proposed H-bond contact',28,INK)
b.ion(660,660,True,True);b.text(702,671,'IL cation',28,INK)

# 3. A qualitative double-helical arrangement, explicitly not atomistic.
c=Scene('03_有序双螺旋_矢量示意','Ordered starch arrangement')
c.ellipse(75,154,850,387,'#F8FBFE',BORDER,2,[9,8])
for xx in [245,405,565,725]:
    phase=(xx-145)/7.1*math.pi/12
    reach=abs(22*math.sin(phase))
    c.line(xx,259+reach,xx,416-reach,HBOND,2.8,[9,7])
for center in [259,416]:
    for phase,col in [(0,BLUE),(math.pi,LIGHT)]:
        pts=[(145+i*7.1,center+22*math.sin(i*math.pi/12+phase)) for i in range(101)]
        c.path(pts,col,5)
        for i in range(0,101,6):
            xx,yy=pts[i];c.ellipse(xx-4.5,yy-4.5,9,9,'#FFFFFF',col,2)
c.text(500,587,'Paired glucan chains: conceptual double helices',28,INK,anchor='middle')
c.line(146,639,209,639,HBOND,2.8,[9,7]);c.text(232,649,'Proposed intermolecular contacts',28,INK)

# 4. A proposed disordered arrangement, not a simulation snapshot.
d=Scene('04_无序链离子作用_矢量示意','Disordered starch / ion arrangement')
d.ellipse(70,151,860,405,'#FBFCFE',BORDER,2,[9,8])
chains=[[(130,275),(193,240),(271,270),(361,240),(431,258)],[(420,206),(493,232),(576,209),(663,247),(754,219),(854,270)],[(125,363),(212,335),(298,354),(394,318),(473,350)],[(482,356),(557,333),(649,362),(729,329),(881,360)],[(142,458),(234,425),(322,448),(397,410)],[(458,456),(541,436),(610,471),(715,438),(855,456)]]
chain_paths=[d.curve(pts,BLUE if i%2==0 else LIGHT,4.8) for i,pts in enumerate(chains)]
def point_at_x(points,x):
    for p,q in zip(points,points[1:]):
        if p[0]<=x<=q[0]:
            t=(x-p[0])/max(1e-9,q[0]-p[0]);return (x,p[1]+t*(q[1]-p[1]))
    raise ValueError(x)
for top,bottom,x in [(0,2,279),(1,3,629),(3,5,721)]:
    p=point_at_x(chain_paths[top]['pts'],x);q=point_at_x(chain_paths[bottom]['pts'],x)
    d.line(*p,*q,HBOND,2.8,[9,7])
for x,y,pos in [(255,304,False),(537,281,True),(757,290,False),(339,416,True),(599,405,False)]:d.ion(x,y,pos)
d.text(500,593,'Illustrative chain separation and ion association',28,INK,anchor='middle')
d.ion(145,653,True,True);d.text(185,664,'IL cation',28,INK)
d.ion(427,653,False,True);d.text(467,664,'IL anion',28,INK)
d.line(708,652,759,652,HBOND,2.8,[9,7]);d.text(782,664,'Contact',28,INK)

scenes=[a,b,c,d]
prs=Presentation();prs.slide_width=Inches(10);prs.slide_height=Inches(7.2)
for sc in scenes:
    sc.svg(OUT/(sc.name+'.svg'));sc.pdf(OUT/(sc.name+'.pdf'));to_ppt(sc,prs)
prs.core_properties.title='Four qualitative starch / ionic-liquid schematics';prs.core_properties.author=''
prs.save(OUT/'四幅机理示意图_矢量重绘_可编辑.pptx')
(OUT/'drawing_scene_graph.json').write_text(json.dumps([{'name':s.name,'title':s.title,'items':s.items} for s in scenes],ensure_ascii=False,indent=2))

notes='''四幅机理示意图：作者核对稿

交付：4个SVG、4个矢量PDF、4页原生可编辑PPT、结构MOL文件及化学清单。
SVG和单幅PDF按89 mm宽导出；主要标签为28画布单位，最终约7.1 pt；主要线宽约0.6–1.3 pt。

本次采用程序化矢量绘图与RDKit化学绘图；不含生成式图像位图。
这仍属于AI辅助制作，不能承诺被判定为“非AI”。投稿须遵守目标期刊的工具使用和披露政策。

科学边界与作者需确认的内容：
1. 装置为简化示意，电极材料、接线及真实实验装置需作者确认；未标未经确认的电压/频率。
2. 氢键图是可能接触的示意，虚线位置不是计算所得或实测距离；不表示相互作用强弱排序。
3. 糖链为C1–O–C4相连的三单元连接结构，省略全部立体化学，不是淀粉完整立体结构。
4. 双螺旋和无序链是概念性排列，不是分子动力学轨迹、原子构象或实验图像。
5. RDKit已检查氯离子、乙酸根、Bmim/Amim/Emim的基本价态、电荷、分子式；缩写与实际试剂身份仍需确认。
6. PubChem接口当前被代理返回403，未完成外部数据库身份核对；未声称有此验证。
7. 未重绘原始柱状图；如用于论文，数值图必须由原始数据和真实误差重新绘制。

建议图注（须结合实验/文献修改）：
“Qualitative schematics illustrating the MEF apparatus and proposed starch–ionic-liquid interactions. Contact positions, helix arrangements and chain distributions are illustrative and are not optimized molecular geometries or simulation snapshots. Stereochemistry is omitted from the glucan connectivity diagram.”
'''
(OUT/'使用说明与科学核对事项.txt').write_text(notes,encoding='utf-8')
print(OUT/'四幅机理示意图_矢量重绘_可编辑.pptx')
print('Native slide object counts:',[len(s.shapes) for s in prs.slides])
