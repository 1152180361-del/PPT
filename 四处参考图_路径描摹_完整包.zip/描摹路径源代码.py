"""Manual point/path transcription of four visible reference regions.

Reference is the user's chat preview, not a locally available original bitmap.
No image-generation model, image embedding or bitmap tracing is used.
"""
from pathlib import Path
import math,json,html,re
from collections import OrderedDict
import numpy as np
from pptx import Presentation
from pptx.util import Inches,Pt
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.oxml.xmlchemy import OxmlElement
from svgpathtools import parse_path
from reportlab.pdfbase import pdfmetrics

OUT=Path('/workspace/manual-trace');OUT.mkdir(exist_ok=True)
NS='http://www.inkscape.org/namespaces/inkscape'
INK='#1A1A1A';BLUE='#264E83';GREEN='#6BAA35';ORANGE='#D26516'

class Trace:
    def __init__(self,name,bbox):self.name=name;self.bbox=bbox;self.items=[];self.layer='paths'
    def add(self,kind,**kw):self.items.append(dict(kind=kind,layer=self.layer,**kw));return self.items[-1]
    def path(self,d,fill='none',stroke=INK,sw=.65,opacity=1,dash=None):return self.add('path',d=d,fill=fill,stroke=stroke,sw=sw,opacity=opacity,dash=dash)
    def poly(self,pts,fill='none',stroke=INK,sw=.65,opacity=1):return self.path('M '+' L '.join(f'{x},{y}' for x,y in pts)+' Z',fill,stroke,sw,opacity)
    def line(self,x1,y1,x2,y2,stroke=INK,sw=.65,dash=None):return self.path(f'M{x1},{y1} L{x2},{y2}',stroke=stroke,sw=sw,dash=dash)
    def ellipse(self,x,y,w,h,fill='none',stroke=INK,sw=.65,opacity=1):return self.add('ellipse',x=x,y=y,w=w,h=h,fill=fill,stroke=stroke,sw=sw,opacity=opacity)
    def rect(self,x,y,w,h,fill='none',stroke=INK,sw=.65,r=0,opacity=1):return self.add('rect',x=x,y=y,w=w,h=h,fill=fill,stroke=stroke,sw=sw,r=r,opacity=opacity)
    def text(self,x,y,value,size=9,color=INK,bold=False,anchor='start',family='Times New Roman'):return self.add('text',x=x,y=y,value=value,size=size,color=color,bold=bold,anchor=anchor,family=family)
    def wire(self,pts,color,width=1):
        self.path(catmull(pts),stroke=color,sw=width)
    def ion(self,cx,cy,r=8):
        self.ellipse(cx-r,cy-r,2*r,2*r,grad(['#A0D65B','#6AAE39','#347B1D'],90),'#437B28',.35)
        self.ellipse(cx-r*.56,cy-r*.65,r*.64,r*.33,'#E7F4CF','none',0,.24)
        self.text(cx,cy+r*.38,'−',r*1.12,'#FFFFFF',True,'middle')
    def cation(self,cx,cy,s=17,angle=0):
        # Explicitly rotated path vertices retain native editability.
        a=math.radians(angle)
        def rt(x,y):return (cx+x*math.cos(a)-y*math.sin(a),cy+x*math.sin(a)+y*math.cos(a))
        p=[rt(-s/2,-s/2),rt(s/2,-s/2),rt(s/2,s/2),rt(-s/2,s/2)]
        self.poly(p,grad(['#EFA14D','#DE751F','#B44808'],90),'#A54D12',.45)
        self.line(*rt(-s*.3,-s*.32),*rt(s*.3,-s*.32),'#FFD39B',.7)
        self.line(*rt(-s*.22,0),*rt(s*.22,0),'#FFFFFF',1.1)
        self.line(*rt(0,-s*.22),*rt(0,s*.22),'#FFFFFF',1.1)
    def svg(self,path):
        defs=[];rows=[];gi=0
        def paint(v):
            nonlocal gi
            if not isinstance(v,dict):return v
            gi+=1;ident=f'grad{gi}'
            angle=v.get('angle',0);a=math.radians(angle);dx=50*math.cos(a);dy=50*math.sin(a)
            stops=''.join(f'<stop offset="{i/(len(v["colors"])-1):.4f}" stop-color="{c}"/>' for i,c in enumerate(v['colors']))
            defs.append(f'<linearGradient id="{ident}" x1="{50-dx}%" y1="{50-dy}%" x2="{50+dx}%" y2="{50+dy}%">{stops}</linearGradient>')
            return f'url(#{ident})'
        for i,q in enumerate(self.items):
            if q['kind']=='text':
                rows.append((q['layer'],f'<text x="{q["x"]}" y="{q["y"]}" font-size="{q["size"]}" fill="{q["color"]}" font-family="{q["family"]},serif" font-weight="{700 if q["bold"] else 400}" text-anchor="{q["anchor"]}">{html.escape(q["value"])}</text>'));continue
            attrs=f'fill="{paint(q["fill"])}" stroke="{q["stroke"]}" stroke-width="{q["sw"]}" opacity="{q["opacity"]}" stroke-linecap="round" stroke-linejoin="round"'
            if q.get('dash'):attrs+=' stroke-dasharray="'+' '.join(map(str,q['dash']))+'"'
            if q['kind']=='path':e=f'<path id="path{i}" d="{q["d"]}" {attrs}/>'
            elif q['kind']=='rect':e=f'<rect x="{q["x"]}" y="{q["y"]}" width="{q["w"]}" height="{q["h"]}" rx="{q["r"]}" {attrs}/>'
            else:e=f'<ellipse cx="{q["x"]+q["w"]/2}" cy="{q["y"]+q["h"]/2}" rx="{q["w"]/2}" ry="{q["h"]/2}" {attrs}/>'
            rows.append((q['layer'],e))
        x,y,w,h=self.bbox;header=f'<svg xmlns="http://www.w3.org/2000/svg" xmlns:inkscape="http://www.inkscape.org/namespaces/inkscape" width="89mm" height="{89*h/w:.3f}mm" viewBox="{x} {y} {w} {h}">'
        body=[header,f'<title>{html.escape(self.name)}</title>','<defs>'+''.join(defs)+'</defs>'];current=None;seq=0
        for layer,e in rows:
            if layer!=current:
                if current is not None:body.append('</g>')
                seq+=1;body.append(f'<g id="layer{seq}" inkscape:groupmode="layer" inkscape:label="{html.escape(layer)}">');current=layer
            body.append(e)
        if current is not None:body.append('</g>')
        body.append('</svg>');Path(path).write_text('\n'.join(body),encoding='utf-8')

def grad(colors,angle=0):return {'colors':colors,'angle':angle}
def catmull(points):
    p=[points[0]]+points+[points[-1]];s=f'M{points[0][0]},{points[0][1]}'
    for i in range(1,len(p)-2):
        a,b,c,d=p[i-1:i+3]
        c1=(b[0]+(c[0]-a[0])/6,b[1]+(c[1]-a[1])/6);c2=(c[0]-(d[0]-b[0])/6,c[1]-(d[1]-b[1])/6)
        s+=f' C{c1[0]},{c1[1]} {c2[0]},{c2[1]} {c[0]},{c[1]}'
    return s
def ccol(v):return RGBColor.from_string(v.lstrip('#'))
def render_ppt(trace,slide,dest=None):
    x0,y0,w,h=trace.bbox
    dest=dest or trace.bbox;dx,dy,dw,dh=dest;sx,sy=dw/w,dh/h;sf=(sx+sy)/2
    tr=lambda x,y:(dx+(x-x0)*sx,dy+(y-y0)*sy)
    members=[]
    for q in trace.items:
        kind=q['kind']
        if kind=='text':
            metric_font=('Times-Bold' if q['bold'] else 'Times-Roman') if q['family']=='Times New Roman' else ('Helvetica-Bold' if q['bold'] else 'Helvetica')
            tw=max(pdfmetrics.stringWidth(q['value'],metric_font,q['size']),q['size']*.9);tx=q['x']-(tw/2 if q['anchor']=='middle' else tw if q['anchor']=='end' else 0);xx,yy=tr(tx,q['y']-q['size']*1.0)
            sh=slide.shapes.add_textbox(Inches(xx/100),Inches(yy/100),Inches((tw+q['size']*.8)*sx/100),Inches(q['size']*1.7*sy/100))
            tf=sh.text_frame;tf.word_wrap=False;tf.margin_left=tf.margin_right=tf.margin_top=tf.margin_bottom=0;p=tf.paragraphs[0];p.text=q['value'];p.font.name=q['family'];p.font.size=Pt(q['size']*.72*sf);p.font.bold=q['bold'];p.font.color.rgb=ccol(q['color']);p.space_after=0
        elif kind in ('rect','ellipse'):
            xx,yy=tr(q['x'],q['y']);typ=MSO_SHAPE.OVAL if kind=='ellipse' else MSO_SHAPE.ROUNDED_RECTANGLE if q['r'] else MSO_SHAPE.RECTANGLE
            sh=slide.shapes.add_shape(typ,Inches(xx/100),Inches(yy/100),Inches(q['w']*sx/100),Inches(q['h']*sy/100))
            if kind=='rect' and q['r']:sh.adjustments[0]=min(.49,q['r']/max(.1,min(q['w'],q['h'])))
        else:
            path=parse_path(q['d']);points=[]
            for seg in path:
                n=1 if seg.__class__.__name__ in ('Line','Close') else max(8,int(seg.length()/1.4))
                for i in range(n):
                    z=seg.point(i/n);points.append(tr(z.real,z.imag))
            z=path[-1].end;points.append(tr(z.real,z.imag))
            points=[(px*100,py*100) for px,py in points]
            first=points[0];b=slide.shapes.build_freeform(*first,scale=Inches(.0001));b.add_line_segments(points[1:],close=q['d'].strip().upper().endswith('Z'));sh=b.convert_to_shape()
        sh.name=q.get('value',q['layer'])[:100]
        if kind!='text':
            fill=q['fill']
            if fill=='none':sh.fill.background()
            elif isinstance(fill,dict):
                sp=sh._element.spPr
                for old in list(sp):
                    if old.tag.split('}')[-1] in ('solidFill','gradFill','noFill'):sp.remove(old)
                g=OxmlElement('a:gradFill');lst=OxmlElement('a:gsLst')
                for i,c in enumerate(fill['colors']):
                    st=OxmlElement('a:gs');st.set('pos',str(round(i/(len(fill['colors'])-1)*100000)));rgb=OxmlElement('a:srgbClr');rgb.set('val',c.lstrip('#'))
                    if q['opacity']<1:
                        alpha=OxmlElement('a:alpha');alpha.set('val',str(round(q['opacity']*100000)));rgb.append(alpha)
                    st.append(rgb);lst.append(st)
                g.append(lst);ln=OxmlElement('a:lin');ln.set('ang',str(round(fill['angle']*60000)));ln.set('scaled','1');g.append(ln);sp.append(g)
            else:
                sh.fill.solid();sh.fill.fore_color.rgb=ccol(fill)
                if q['opacity']<1:
                    rgb=sh._element.spPr.find('.//{http://schemas.openxmlformats.org/drawingml/2006/main}srgbClr');alpha=OxmlElement('a:alpha');alpha.set('val',str(round(q['opacity']*100000)));rgb.append(alpha)
            if q['stroke']=='none' or q['sw']==0:sh.line.fill.background()
            else:
                sh.line.color.rgb=ccol(q['stroke']);sh.line.width=Pt(q['sw']*.72*sf);ln=sh._element.spPr.get_or_add_ln();ln.set('cap','rnd');ln.append(OxmlElement('a:round'))
                if q.get('dash'):sh.line.dash_style=4
            sh._element.spPr.append(OxmlElement('a:effectLst'))
            for ref in sh._element.findall('.//{http://schemas.openxmlformats.org/drawingml/2006/main}effectRef'):ref.set('idx','0')
        members.append(sh)
    group=slide.shapes.add_group_shape(members);group.name=trace.name+' — 手动路径描摹';return group

# 1 — Explicit manual outline points of the visible MEF apparatus.
a=Trace('01_MEF装置_按参考图描线',(20,86,268,247))
a.layer='01 金属底座与控制面板'
a.poly([(20,241),(45,211),(287,211),(262,241)],grad(['#C7C7C5','#DEDEDC','#BBBBBA'],20),'#8A8B88',.4)
a.poly([(262,241),(287,211),(287,306),(262,333)],grad(['#999A96','#C6C7C3'],0),'#8C8E89',.4)
a.rect(20,241,242,92,grad(['#AAAAA8','#C6C6C4','#ADADAA'],0),'#989A96',.4)
a.rect(65,251,188,76,grad(['#F4F4F1','#B9B9B7','#F8F8F7'],0),'#62635E',.8)
a.rect(69,255,180,68,grad(['#DBDCD9','#F2F2F0','#D0D1CD'],0),'#A4A59F',.5)
a.rect(76,267,57,45,'#282B2C','#777A74',.8)
a.rect(81,272,47,35,grad(['#59ACDE','#1E6CB2'],90),'#6B9ABF',.35)
a.text(103,286,'4.8V',13.0,'#FFFFFF',True,'middle')
a.text(103,300,'50Hz',13.0,'#FFFFFF',True,'middle')
a.rect(30,264,23,44,'#22221F','#70716B',.45)
a.rect(33,267,17,38,grad(['#FF2B1A','#E60000','#A30000'],90),'#8E1107',.45)
a.text(41.5,280,'I',11,'#FFFFFF',True,'middle');a.text(41.5,299,'0',11,'#FFFFFF',True,'middle')
a.text(150,267,'V',5.7,'#343932',True,'middle')
for yy in [276,292,307]:a.ellipse(147,yy-3,6,6,grad(['#FFFFFF','#AEB1A8'],90),'#767D70',.35)
for yy in [274,296]:a.poly([(166,yy-4),(163,yy+3),(169,yy+3)],'#323730','none',0)
a.ellipse(183,283,19,19,grad(['#E7E8E5','#9DA29C','#CFD2CB'],0),'#656D60',.5)
a.path('M178,281 C182,273 199,274 208,282',stroke='#60685D',sw=.6)
a.line(203,279,208,282,'#60685D',.5);a.line(207,278,208,282,'#60685D',.5)
a.text(178,313,'Voltage',7.0,'#242C23')
a.rect(218,284,22,18,'#C5CBC0','#A3AB9E',.4)
a.rect(224,288,11,9,'#343D34','#8F978A',.4);a.ellipse(226,289,7,7,'#203D4D','none',0)
a.layer='02 烧杯、黄色液体及电极'
a.path('M43,132 L43,220 C44,238 144,239 146,220 L146,132 Z',grad(['#DCDDCB','#FBFBE7','#B8BBA9'],0),'#8F9582',.65)
a.rect(45,167,99,54,grad(['#DEC55D','#F4E28C','#D9C562'],0),'none',0)
a.ellipse(45,155,99,23,grad(['#F6E6A5','#E0CC77'],90),'#C9BC72',.4)
a.ellipse(44,209,102,27,grad(['#D8C26D','#F3E18D','#CBB967'],0),'#999A76',.55)
for xx in [78,121]:
    a.rect(xx,131,8,69,grad(['#7E8379','#E4E4D9','#686E63'],0),'#9FA28F',.2)
    a.poly([(xx+1,197),(xx+7,197),(xx+7,211),(xx+4,207),(xx+1,210)],'#5D6253','none',0)
a.rect(51,145,7,66,'#FFFFFF','none',0,opacity=.3)
a.path('M44,220 C46,233 143,234 145,220',stroke='#FFFFFF',sw=1.2,opacity=.55)
a.rect(42,126,104,15,grad(['#9A9D99','#D6D8D3','#8D928B'],0),'#90968C',.3)
a.ellipse(42,113,104,28,grad(['#FFFFFF','#D4D7D1','#F5F5F0'],0),'#B6BBB1',.45)
for xx,yy in [(73,118),(117,112)]:
    a.rect(xx,yy,18,10,grad(['#151C15','#5C6357','#070B06'],0),'none',0)
    a.ellipse(xx,yy-4,18,8,'#11170F','#555D50',.3)
for xx,yy in [(80,99),(123,91)]:
    a.rect(xx,yy,5,27,grad(['#B28E19','#FCE697','#A6891C'],0),'#AA8D26',.35)
    for dy in [5,13,21]:a.line(xx,yy+dy,xx+5,yy+dy-2,'#B59025',.4)
a.line(68,206,94,218,'#454B3F',.4);a.line(69,203,69,209,'#454B3F',.4)
a.line(113,210,133,208,'#454B3F',.4)
a.layer='03 红蓝接线'
a.wire([(82,103),(85,139),(89,191),(101,253),(118,305),(132,324),(164,319),(204,303),(229,294)],'#E61617',1.25)
a.wire([(124,96),(131,141),(146,181),(169,222),(202,264),(230,293)],'#1B56A0',1.05)

# 2 — Hand-positioned chair-like contours and visible atom/ion marks.
# These trace geometry/appearance only; stereochemistry and tiny source labels need review.
b=Trace('02_氢键化学放大_按参考图描线',(96,733,273,105))
b.layer='01 原图椅式轮廓与糖苷连接'
for d in [
 'M136,774 L151,769 L177,766 L189,782 L173,792 L148,788 Z',
 'M207,761 L222,758 L247,756 L260,769 L244,779 L219,775 Z',
 'M280,785 L295,782 L320,780 L333,793 L317,803 L292,799 Z',
 'M189,782 L198,776 L207,761',
 'M260,769 L272,776 L280,785',
 'M151,769 L157,753 L181,751',
 'M222,758 L232,742 L252,740',
 'M295,782 L304,768 L331,769',
 'M136,774 L122,780 L115,777',
 'M148,788 L143,801',
 'M173,792 L182,806',
 'M219,775 L209,789',
 'M244,779 L250,796',
 'M292,799 L280,812',
 'M317,803 L318,816',
 'M333,793 L350,796 L362,801']:
    b.path(d,stroke='#171717',sw=.65)
for x,y,w,h in [(173,760,9,10),(243,749,10,10),(316,773,10,10),(194,771,10,10),(267,771,10,10)]:b.rect(x,y,w,h,'#FFFFFF','none',0)
for x,y,label in [(177,772,'O'),(247,762,'O'),(320,786,'O'),(198,780,'O'),(272,780,'O'),(180,754,'O'),(251,743,'O'),(331,773,'O'),(115,783,'O'),(132,807,'HO'),(178,810,'OH'),(205,796,'O'),(247,802,'OH'),(270,817,'HO'),(313,822,'OH'),(351,806,'O')]:b.text(x,y,label,8.1,'#111111')
b.path('M114,778 L106,775',stroke='#111111',sw=.55,dash=[1,2])
b.path('M362,801 L368,805',stroke='#111111',sw=.55,dash=[1,2])
b.layer='02 氢键虚线'
for xy in [(164,753,183,755),(174,760,189,769),(145,804,181,805),(244,792,235,778),(283,810,275,820),(325,812,321,819)]:b.line(*xy,'#EF2626',.65,[1.2,1.5])
b.layer='03 原图离子位置'
for x,y in [(239,778),(208,826),(321,821)]:b.ion(x,y,7.8)
for x,y,angle in [(158,751,25),(140,823,34),(271,825,24)]:b.cation(x,y,16,angle)

# Centre the visible oxygen labels on the traced vertices and leave bond gaps.
# These are hand-positioned connectivity contours, not a stereochemical assertion.
overlays=[q for q in b.items if q['layer']!='01 原图椅式轮廓与糖苷连接']
b.items=[];b.layer='01 原图椅式轮廓与糖苷连接'
rings=[[(136,774),(151,769),(177,766),(189,782),(173,792),(148,788)],[(207,761),(222,758),(247,756),(260,769),(244,779),(219,775)],[(280,785),(295,782),(320,780),(333,793),(317,803),(292,799)]]
atoms={(177,766):'O',(247,756):'O',(320,780):'O',(198,776):'O',(272,776):'O',(181,751):'OH',(252,740):'OH',(331,769):'OH',(122,780):'HO',(143,801):'HO',(182,806):'OH',(209,789):'HO',(250,796):'OH',(280,812):'HO',(324,808):'OH',(350,796):'OH'}
bonds=[]
for ring in rings:bonds += list(zip(ring,ring[1:]+ring[:1]))
bonds += [((189,782),(198,776)),((198,776),(207,761)),((260,769),(272,776)),((272,776),(280,785)),((151,769),(157,753)),((157,753),(181,751)),((222,758),(232,742)),((232,742),(252,740)),((295,782),(304,768)),((304,768),(331,769)),((136,774),(122,780)),((148,788),(143,801)),((173,792),(182,806)),((219,775),(209,789)),((244,779),(250,796)),((292,799),(280,812)),((317,803),(324,808)),((333,793),(350,796))]
for p,q in bonds:
    dx=q[0]-p[0];dy=q[1]-p[1];length=math.hypot(dx,dy);ux,uy=dx/length,dy/length
    trim0=4 if p in atoms else 0;trim1=4 if q in atoms else 0
    b.line(p[0]+ux*trim0,p[1]+uy*trim0,q[0]-ux*trim1,q[1]-uy*trim1,'#171717',.65)
for (x,y),label in atoms.items():b.text(x-(8.8 if label=='HO' else 2.9),y+2.7,label,8.1,'#111111')
b.items += overlays

# 3 — Explicit control points follow the original pair of stacked helical ribbons.
c=Trace('03_有序双螺旋_按参考图描线',(503,576,141,95))
front=[(505,595),(512,592),(521,582),(527,583),(537,595),(545,594),(555,583),(561,582),(571,595),(578,594),(589,582),(596,584),(606,596),(613,594),(624,583),(631,586),(641,599)]
back=[(505,589),(513,595),(522,606),(529,605),(538,592),(546,595),(555,606),(562,604),(571,591),(579,594),(590,607),(597,604),(605,592),(614,595),(624,606),(631,603),(641,591)]
c.layer='01 原图氢键位置'
for xy in [(511,610,519,637),(537,610,531,636),(561,610,568,636),(594,610,587,636),(625,610,618,636)]:c.line(*xy,'#EC2424',.8,[1.1,1.8])
for shift in [0,58]:
    c.layer=f'02 螺旋带 y{shift}'
    for pts in [back,front]:
        pp=[(x,y+shift) for x,y in pts]
        c.wire(pp,'#2A4D87',7.0)
        c.wire(pp,'#AFC5E6',5.5)
        c.wire([(x,y-.65) for x,y in pp],'#E0E9F7',1.9)
        c.wire([(x,y+1.6) for x,y in pp],'#7D9AC9',1.05)
    for x,y in [(522,583),(557,583),(591,583),(626,584),(522,605),(557,605),(590,606),(625,605)]:
        c.ellipse(x-1.7,y+shift-1.7,3.4,3.4,'#E7EFFB','#4E70A9',.45)

# 4 — Original irregular curve paths and ion positions, rather than a new layout.
d=Trace('04_无序链离子作用_按参考图描线',(800,558,205,139))
chain_paths=[
 [(829,582),(845,586),(858,589),(869,575),(887,577),(903,588),(919,586),(936,575),(953,577),(978,582)],
 [(801,619),(815,626),(830,620),(847,626),(860,637),(876,633),(889,621),(906,624),(923,630),(940,630),(955,622),(976,628),(991,638),(1003,635)],
 [(816,660),(830,649),(844,655),(856,669),(869,665),(880,652),(894,646),(909,652),(923,665),(941,670),(956,666),(974,669),(993,661)],
 [(838,603),(852,598),(865,609),(879,606),(891,615),(903,611),(919,620),(936,616),(952,607),(975,607),(992,616)]]
d.layer='01 不规则链与蓝色轮廓'
for pts in chain_paths:
    d.wire(pts,'#294B7C',3.1)
    d.wire([(x,y-.35) for x,y in pts],'#7699CD',1.35)
d.path('M865,572 L870,565 L874,557',stroke='#244D82',sw=1.0,dash=[2,2])
d.layer='02 原图虚线连接'
for xy in [(816,631,826,656),(830,629,841,653),(858,612,850,625),(877,600,887,625),(897,607,908,645),(922,609,923,649),(946,601,950,628),(976,608,978,634),(892,670,915,680)]:d.line(*xy,'#E92D32',.7,[1.4,1.8])
d.layer='03 原图离子'
for x,y in [(843,619),(920,575),(908,658)]:d.ion(x,y,8.2)
for x,y,angle in [(889,598,-27),(963,650,-20)]:d.cation(x,y,16,-20 if angle==-20 else -27)

traces=[a,b,c,d]
for t in traces:t.svg(OUT/(t.name+'.svg'))
(OUT/'手动控制点.json').write_text(json.dumps([{'name':t.name,'bbox':t.bbox,'items':t.items} for t in traces],ensure_ascii=False,indent=2))

# Native 4-slide asset deck. Canvas stays uniform; source aspect ratios are preserved.
prs=Presentation();prs.slide_width=Inches(10);prs.slide_height=Inches(7.2)
for i,t in enumerate(traces):
    sl=prs.slides.add_slide(prs.slide_layouts[6]);x,y,w,h=t.bbox;scale=min(850/w,570/h);dw,dh=w*scale,h*scale
    render_ppt(t,sl,((1000-dw)/2,105+(570-dh)/2,dw,dh))
    label=sl.shapes.add_textbox(Inches(.35),Inches(.2),Inches(9.4),Inches(.55));p=label.text_frame.paragraphs[0];p.text=f'{i+1}. '+t.name.split('_')[1];p.font.name='Arial';p.font.size=Pt(22);p.font.color.rgb=ccol('#244E83')
    sl.notes_slide.notes_text_frame.text='按对话中参考图可见轮廓手动录入路径；没有图像生成调用，没有嵌入原位图。不是自动逐像素追踪。化学细小标注与立体化学需作者核对。'
prs.core_properties.title='四处原图视觉轮廓手动描摹';prs.core_properties.author=''
prs.save(OUT/'四处原图_手动路径描摹_可编辑.pptx')

# Replace the four original raster objects in the existing poster with native paths.
poster=Presentation('/workspace/PPT/电场与离子液体辅助淀粉破坏机制_新版_可编辑.pptx');sl=poster.slides[0]
for old in list(sl.shapes):
    if old.has_text_frame and old.text=='4.8V\n50Hz':old._element.getparent().remove(old._element)
    elif old.has_text_frame and old.text in ('[Amim]⁺','[Bmim]⁺','[Emim]⁺') and old.top/9144<220:
        for para in old.text_frame.paragraphs:
            para.font.size=Pt(11.0)
            for run in para.runs:run.font.size=Pt(11.0)
pics=[s for s in sl.shapes if s.shape_type==13];assert len(pics)==4
for pic,t in zip(pics,traces):
    rect=(pic.left/9144,pic.top/9144,pic.width/9144,pic.height/9144)
    blip=pic._element.find('.//{http://schemas.openxmlformats.org/drawingml/2006/main}blip')
    rid=blip.get('{http://schemas.openxmlformats.org/officeDocument/2006/relationships}embed')
    parent=pic._element.getparent();idx=list(parent).index(pic._element);parent.remove(pic._element)
    remaining=[el.get('{http://schemas.openxmlformats.org/officeDocument/2006/relationships}embed') for el in sl._element.iter('{http://schemas.openxmlformats.org/drawingml/2006/main}blip')]
    if rid not in remaining:sl.part.drop_rel(rid)
    group=render_ppt(t,sl,rect);parent.remove(group._element);parent.insert(idx,group._element)
sl.notes_slide.notes_text_frame.text='四处图像已替换为按参考预览手动标定的原生路径。未使用图像生成模型；不是原始位图逐像素追踪。化学结构细节及机理仍需作者核对。原图重复面板编号和迁移图例原文保留；柱形仍按截图外观描摹，不能作为已恢复的原始实验数值。'
poster.save(OUT/'淀粉机制整图_四处替换为描摹矢量_可编辑.pptx')
print(OUT)
print('Per-asset vector element counts:',[len(t.items) for t in traces])
